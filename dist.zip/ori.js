const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const PhotoSchema = new Schema({
  url: String,
});

module.exports = mongoose.model("Photo", PhotoSchema);
